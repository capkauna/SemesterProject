package Data;

import Data.AnimalDTO.Bird;
import Data.AnimalDTO.Date;
import Data.AnimalDTO.Pet;

public class TestClass
{
  public static void main(String[] args)
  {

  }
}
