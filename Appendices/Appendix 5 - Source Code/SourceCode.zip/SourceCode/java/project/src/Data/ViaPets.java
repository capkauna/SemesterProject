package Data;

import Data.AnimalDTO.Pet;

import java.util.ArrayList;

public class ViaPets {


  public ArrayList<Customer> getAllCustomers() {
    return new ArrayList<>();
  }

  public ArrayList<Booking> getAllBookings() {
    return new ArrayList<>(); // Placeholder
  }

  public ArrayList<Sale> getAllPetsForSale() {
    return new ArrayList<>();
  }

  public ArrayList<Pet> getAllPets() {
    return new ArrayList<>();
  }
}